How to use HelloCordova Sample App
1. add InfineaSDKCordova to the root HelloCordova
2. move build.json from InfineaSDKCordova to the root of HelloCordova
3. add InfineaSDK.framework to InfineaSDKCordova -> src -> ios
4. add the plugin to the project "cordova plugin add InfineaSDKCordova"
5. open the .xcworkspace
6. Add your developer key in staging -> www -> js -> index.js


Get Developer key from the developer key
- NOTE: go to your developer portal -> profile -> my dev keys -> generate a key
- NOTE: bundle ID must match the one in the project perfectly in order for it work correctly 

